// generated from rosidl_generator_c/resource/idl.h.em
// with input from actionlib_msgs:msg/GoalStatusArray.idl
// generated code does not contain a copyright notice

#ifndef ACTIONLIB_MSGS__MSG__GOAL_STATUS_ARRAY_H_
#define ACTIONLIB_MSGS__MSG__GOAL_STATUS_ARRAY_H_

#include "actionlib_msgs/msg/detail/goal_status_array__struct.h"
#include "actionlib_msgs/msg/detail/goal_status_array__functions.h"
#include "actionlib_msgs/msg/detail/goal_status_array__type_support.h"

#endif  // ACTIONLIB_MSGS__MSG__GOAL_STATUS_ARRAY_H_
