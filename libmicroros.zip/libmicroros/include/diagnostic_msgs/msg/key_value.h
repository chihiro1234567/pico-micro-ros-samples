// generated from rosidl_generator_c/resource/idl.h.em
// with input from diagnostic_msgs:msg/KeyValue.idl
// generated code does not contain a copyright notice

#ifndef DIAGNOSTIC_MSGS__MSG__KEY_VALUE_H_
#define DIAGNOSTIC_MSGS__MSG__KEY_VALUE_H_

#include "diagnostic_msgs/msg/detail/key_value__struct.h"
#include "diagnostic_msgs/msg/detail/key_value__functions.h"
#include "diagnostic_msgs/msg/detail/key_value__type_support.h"

#endif  // DIAGNOSTIC_MSGS__MSG__KEY_VALUE_H_
